export type Filter = {
	platform: string
	genre?: string
	tag?: string
	sortBy: string
}
