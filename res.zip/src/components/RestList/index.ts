import RestList from './RestList.container'

export default RestList
