export const BROWSER = 'Web Browser'
export const WINDOWS = 'PC (Windows)'
