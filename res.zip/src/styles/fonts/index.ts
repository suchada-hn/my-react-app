export const fontFamily = 'Arial, Verdana'
