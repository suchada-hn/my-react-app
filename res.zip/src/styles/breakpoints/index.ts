export const breakpoints = {
	tablet: '720px',
	desktop: '1024px',
}
