export type Rest = {
	id: number 
	title: string
	thumbnail: string
	short_description: string
	// game_url: string
	genre: string
	platform: string
	sortBy: number
	isOpen: string
	tag: string
	// publisher: string
	// developer: string
	// release_date: string
	// freetogame_profile_url: string
}
// export type Rest = {
// 	id: number
// 	shopNameTH: string
// 	categoryName: string
// 	subcategoryName: string
// 	coverImageId: string
// 	facilities: []
// 	priceLevel: string
// 	isOpen: string
// 	highlightText: string
// 	recommendedItems: []
// 	addressProvinceName: string
// 	addressDistrictName: string
// }