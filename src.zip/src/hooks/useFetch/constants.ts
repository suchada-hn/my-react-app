export const API_KEY = 'c3557508dbmshc17ac4af6a4db04p1fc99cjsn5d2d63bbeec2'
export const API_HOST = 'free-to-play-games-database.p.rapidapi.com'
