import { useState, useEffect } from 'react'
// import axios from 'axios'
import { Rest } from 'types'
// import { API_HOST, API_KEY } from './constants'
import { Filter } from 'components/RestList/types'

type Response = {
	rests: Rest[]
	error: string
    data: Rest[]
}

const useFetch = (): Response => {
	const [rests, setRests] = useState<Rest[]>([])
	const [err, setErr] = useState<string>('')
    const [data, setData] = useState<Rest[]>([])
    useEffect(() => {
        fetch('https://raw.githubusercontent.com/suchada-hn/res/main/data2.json')
        .then((response) => response.json())
        .then((responseJson) => {
            setData(responseJson)
            setRests(responseJson)
            console.log('set rests')
           
        })
        .catch((error) => {
            console.error(error);
          });
        
        console.log('done');
      },[])


    console.log('final rests')

	return {
        data,
		rests,
		error: err,
	}
}

export default useFetch
