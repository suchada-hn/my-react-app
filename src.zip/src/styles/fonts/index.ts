export const fontFamily = 'Cordia New'
