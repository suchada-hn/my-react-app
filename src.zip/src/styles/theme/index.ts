export const primaryColor = 'lightgray'
export const secondaryColor = '#fff'

export const primaryTextColor = '#000'
export const secondaryTextColor = '#7a8288'
export const tertiaryTextColor = '#fff'

export const backgroundColor = '#7a8288'
