import React, { ReactElement } from 'react'
import windowsIcon from 'assets/icons/windows.svg'
import browserIcon from 'assets/icons/browser.svg'
import { Rest } from 'types'
import { Y,N } from './constants'
import {
	StyledLink,
	Img,
	Title,
	Details,
	Description,
	Icon,
	Genre,
} from './styles'

interface Props {
	content: Rest
}

const RestCard = ({ content }: Props): ReactElement => {
	// const { id, title, thumbnail, short_description, genre, platform } = content
	const { id, title, thumbnail, short_description, genre, platform, isOpen, tag, sortBy } = content	
	const icons = isOpen.split('').map(p => {
		let icon = null
		switch (p.trim()) {
			case Y:
				// icon = "เปิดอยู่"
				icon = (<Icon style={{backgroundColor: 'green'}}>เปิดอยู่</Icon>)
			
				break
			case N:
				// icon = "เปิดอยู่"
				icon = (<Icon style={{backgroundColor: 'red'}}>ปิดแล้ว</Icon>)
				break
				
			default:
				break
		}
		return icon
	})
	const prices = (sortBy: Number): String | null =>{
		// const price = String;
		let price =null
		switch (sortBy) {
			case 1:  price=("$"); break;
			case 2:  price="$$"; break;
			case 3: price="$$$";break;
			case 4:  price="$$$$";break;
			default:
				break
		}
		return price

	}
	prices(sortBy)

		
	// const link = `

	return (
		<StyledLink key={id} to={`/rest/${id}`}>
			<Img key={id} alt={`${title}-logo`} src={thumbnail} />
			<Title >{title}</Title>
			{icons}
			<Description> {prices(sortBy)} | {tag} </Description>
		
			<Details>
				
				<Description>{short_description}</Description>
				<Genre>{genre}</Genre>
				
				
			</Details>
		</StyledLink>
	)
}

export default RestCard
