export const Y = 'Y'
export const N = 'N'

